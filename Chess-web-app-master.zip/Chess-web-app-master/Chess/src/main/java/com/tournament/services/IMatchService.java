package com.tournament.services;
import com.tournament.model.IMatch;

public interface IMatchService {
    void saveMatch(IMatch iMatch);
}
