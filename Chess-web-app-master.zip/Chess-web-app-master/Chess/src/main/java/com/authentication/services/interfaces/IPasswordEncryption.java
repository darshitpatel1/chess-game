package com.authentication.services.interfaces;

public interface IPasswordEncryption {

    String encryptPassword(String passwordToHash);
}
