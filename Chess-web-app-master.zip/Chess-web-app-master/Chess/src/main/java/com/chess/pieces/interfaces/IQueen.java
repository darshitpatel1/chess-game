package com.chess.pieces.interfaces;

public interface IQueen {

    boolean validMove(int finalCordX, int finalCordY);
}
