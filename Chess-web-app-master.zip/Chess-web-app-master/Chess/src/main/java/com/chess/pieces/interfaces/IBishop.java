package com.chess.pieces.interfaces;

public interface IBishop {

    boolean validMove(int destinationX, int destinationY);

}
